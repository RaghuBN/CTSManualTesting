# Java Collection 
# Source 
![Collections](Java-collection-framework-hierarchy.png)
- https://beginnersbook.com/java-collections-tutorials/
- https://en.wikipedia.org/wiki/Java_collections_framework
# Summary 
- interfaces 
- implementations 

# Why/when we use?

# Why not to use

# Performance problems 

# What is Map?

# What is List? 

# What is set?


