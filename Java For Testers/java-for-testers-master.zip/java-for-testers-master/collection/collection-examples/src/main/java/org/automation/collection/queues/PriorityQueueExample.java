package org.automation.collection.queues;

public class PriorityQueueExample {
}
