package org.automation.collection.maps;

import java.util.Hashtable;

public class HashTableExample {
    public static void main(String[] args) {
        Hashtable<Long,String> items = new Hashtable();

    }
}
