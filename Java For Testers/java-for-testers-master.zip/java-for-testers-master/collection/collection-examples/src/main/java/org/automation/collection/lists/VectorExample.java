package org.automation.collection.lists;

import java.util.Vector;

public class VectorExample {
    public static void main(String[] args) {
        Vector<String> items = new Vector<>();

    }
}
