package org.automation.collection.maps;

import java.util.IdentityHashMap;

public class IdentityHashMapExample {
    public static void main(String[] args) {
        IdentityHashMap<Long,String> items = new IdentityHashMap();

    }
}
