package org.automation.collection.deques;

import java.util.ArrayDeque;
import java.util.ArrayList;

public class ArrayDequeExample {
    public static void main(String[] args) {
        ArrayDeque<String> items = new ArrayDeque<>();

    }
}
