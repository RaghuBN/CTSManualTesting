package org.automation.collection.lists;

import java.util.LinkedList;

public class LinkedListExample {
    public static void main(String[] args) {
        LinkedList<String> items = new LinkedList<>();

    }
}
