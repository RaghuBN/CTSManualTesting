package org.automation.collection.lists;

import java.util.ArrayList;
import java.util.Stack;

public class ArrayListExample {
    public static void main(String[] args) {
        ArrayList<String> items = new ArrayList<>();

    }
}
