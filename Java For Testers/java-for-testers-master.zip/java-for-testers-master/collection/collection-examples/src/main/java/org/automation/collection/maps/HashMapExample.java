package org.automation.collection.maps;

import java.util.HashMap;

public class HashMapExample {
    public static void main(String[] args) {
        HashMap<Long,String> items = new HashMap();

    }
}
