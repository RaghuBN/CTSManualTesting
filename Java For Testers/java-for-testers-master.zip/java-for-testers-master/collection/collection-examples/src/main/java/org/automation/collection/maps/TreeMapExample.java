package org.automation.collection.maps;

import java.util.TreeMap;

public class TreeMapExample {
    public static void main(String[] args) {
        TreeMap<Long,String> items = new TreeMap();

    }
}
