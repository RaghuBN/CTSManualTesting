package org.automation.collection.maps;

import java.util.LinkedHashMap;

public class LinkedHashMapExample {
    public static void main(String[] args) {
        LinkedHashMap<Long,String> items = new LinkedHashMap();

    }
}
