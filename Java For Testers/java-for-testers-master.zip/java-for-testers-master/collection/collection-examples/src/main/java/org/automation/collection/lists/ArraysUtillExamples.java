package org.automation.collection.lists;

import java.util.Arrays;

public class ArraysUtillExamples {
    //All examples for Arrays , this is a utility for all type of arrays
    public static void main(String[] args) {
        Arrays.asList();
    }
}
