package org.automation.collection.lists;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Stack<String> items = new Stack<>();

    }
}
