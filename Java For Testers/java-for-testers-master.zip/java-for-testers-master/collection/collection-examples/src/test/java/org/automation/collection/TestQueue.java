package org.automation.collection;

public class TestQueue {


    public void testAdd(){
        //adding item
        //count
    }
    public void testRemove(){
        //removing
        //count
    }

    public void testQueueAdd(){
        //adding item
        //added item should be last element of the queue
    }
    public void testQueueRemove(){
        //removing
        //removed item shoult be first added item
    }
}
