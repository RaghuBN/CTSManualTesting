package org.automation.collection;

public class TestMap {
}
