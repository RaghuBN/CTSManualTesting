package org.automation.collection;

public class TestNavigable {
}
