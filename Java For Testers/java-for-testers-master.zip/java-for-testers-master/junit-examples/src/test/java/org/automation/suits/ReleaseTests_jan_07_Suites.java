package org.automation.suits;

public class ReleaseTests_jan_07_Suites {
}
