package org.automation.suits;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
public class BetaTestsSuite {
}
