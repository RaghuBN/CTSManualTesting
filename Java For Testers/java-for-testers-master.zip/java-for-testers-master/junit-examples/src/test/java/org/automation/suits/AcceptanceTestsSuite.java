package org.automation.suits;

public class AcceptanceTestsSuite {
}
