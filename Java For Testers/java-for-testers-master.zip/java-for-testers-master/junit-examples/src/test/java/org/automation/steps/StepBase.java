package org.automation.steps;

public abstract class StepBase {
}
