# Maven command : Regression Test run
mvn -Dtest.suite=org.automation.suits.RegressionTestsSuite.class test