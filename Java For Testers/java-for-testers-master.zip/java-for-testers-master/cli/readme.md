# CLI info details

# Todo 
1. Ci/CD setup
2. Scripts 
3. Jenkisn
