
- https://www.programmingsimplified.com/c-program-print-stars-pyramid
