# Shantonu Solution
