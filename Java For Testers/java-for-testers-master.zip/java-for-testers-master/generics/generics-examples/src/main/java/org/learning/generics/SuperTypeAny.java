package org.learning.generics;

/**
 * Created by SSarker on 12/2/2018.
 */
public abstract class SuperTypeAny {
    public abstract Integer getVal();
    public abstract void setVal(Integer aVal);

    public abstract SuperTypeAny getVal2();
    public SuperTypeAny(Integer integer) {
    }
    public SuperTypeAny() {
    }
}
