package org.learning.generics;

/**
 * Created by SSarker on 12/2/2018.
 */
public interface MyAnyType2 {
}
