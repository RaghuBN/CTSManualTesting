package org.automation.ui.suits;

public class RegressionSuit {
}
