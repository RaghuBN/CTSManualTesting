package org.automation.ui.suits.catagories;

public class RunDealSearchTests {
}
