package org.automation.ui.workflows;

public class Registration {
}
