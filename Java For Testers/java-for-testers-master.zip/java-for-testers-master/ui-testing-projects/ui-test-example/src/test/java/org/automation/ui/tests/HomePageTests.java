package org.automation.ui.tests;

import org.automation.ui.core.TestBase;

public class HomePageTests extends TestBase {
}
