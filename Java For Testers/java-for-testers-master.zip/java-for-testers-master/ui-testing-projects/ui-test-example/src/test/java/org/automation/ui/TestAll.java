package org.automation.ui;

public class TestAll {
}
