package org.automation.ui.core;

public abstract class TestBase {

}
