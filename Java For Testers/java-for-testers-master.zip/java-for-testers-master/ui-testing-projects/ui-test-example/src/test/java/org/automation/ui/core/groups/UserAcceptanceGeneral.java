package org.automation.ui.core.groups;

public interface UserAcceptanceGeneral {
}
