package org.automation.ui;

public class App {
    public static void main(String[] args) {

    }
}
