package org.automation.ui.core;

public class JavaProperties {
}
