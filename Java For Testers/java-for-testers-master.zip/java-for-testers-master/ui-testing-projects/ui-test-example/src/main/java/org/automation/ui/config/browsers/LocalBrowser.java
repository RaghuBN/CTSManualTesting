package org.automation.ui.config.browsers;

 class LocalBrowser {
}
