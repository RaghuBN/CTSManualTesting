package org.automation.ui.pages.travel;

public class TravelPageBase {
}
