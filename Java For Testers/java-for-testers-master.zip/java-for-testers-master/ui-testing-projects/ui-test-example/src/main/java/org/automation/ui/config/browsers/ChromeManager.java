package org.automation.ui.config.browsers;

/***
 * Capabilities
 * profile
 * extentions
 * local storage
 */
class ChromeManager {
}
