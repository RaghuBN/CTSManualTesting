package org.automation.ui.config.browsers;

class BrowserStack {
}
