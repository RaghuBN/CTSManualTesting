package org.automation.ui.pages.groups;

public class GroupPageBase {
}
