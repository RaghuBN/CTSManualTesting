package org.automation.ui.pages.parent;

import org.automation.ui.pages.PageBase;

public abstract class MainSitePageBase extends PageBase {
}
