package org.automation.ui.pages;

/***
 * common behavior of pages
 * URL mapping
 * Common functionality
 * Page init
 */
public abstract class PageBase {
}
