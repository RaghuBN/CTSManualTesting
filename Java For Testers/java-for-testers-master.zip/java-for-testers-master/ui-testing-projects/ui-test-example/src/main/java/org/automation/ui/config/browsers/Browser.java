package org.automation.ui.config.browsers;

public class Browser {
}
