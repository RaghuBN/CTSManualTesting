package org.automation.ui.pages.parent;

/**
 * home page behavior
 *
 */
public class HomePage extends MainSitePageBase {

}
