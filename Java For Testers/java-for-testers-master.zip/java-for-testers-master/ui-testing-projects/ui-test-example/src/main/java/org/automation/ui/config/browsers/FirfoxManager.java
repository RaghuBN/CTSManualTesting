package org.automation.ui.config.browsers;


/***
 * Firefox profile
 * firefox extensions
 * firefox capabilities
 *
 */
class FirfoxManager {
}
