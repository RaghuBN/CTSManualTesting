package org.automation.ui.config;

public class PropertyLoader {
}
