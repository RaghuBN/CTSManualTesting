package org.automation.ui.pages.service;

public class ServicePageBase {
}
