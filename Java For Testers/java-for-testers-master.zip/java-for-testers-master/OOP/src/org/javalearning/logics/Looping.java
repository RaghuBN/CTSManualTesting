package org.javalearning.logics;

public class Looping {
	
	public static void main(String... args) 
	{
		Integer a=Integer.MAX_VALUE;
		Long b=Long.valueOf(a)*2;
		System.out.println(b);
		
	}

}
