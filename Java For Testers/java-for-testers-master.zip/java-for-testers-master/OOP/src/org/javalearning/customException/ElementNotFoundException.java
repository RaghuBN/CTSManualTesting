package org.javalearning.customException;

public class ElementNotFoundException extends Exception {
	
	

}
