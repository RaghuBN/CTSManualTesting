package org.javalearning.customException;

public class ElementMissingException  extends RuntimeException{
	

}
