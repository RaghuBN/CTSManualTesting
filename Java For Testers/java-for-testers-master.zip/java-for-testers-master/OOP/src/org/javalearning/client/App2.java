package org.javalearning.client;

import org.javalearning.abstraction.*;

public class App2 {
	public static void main(String[] args) {
		
	}
}
