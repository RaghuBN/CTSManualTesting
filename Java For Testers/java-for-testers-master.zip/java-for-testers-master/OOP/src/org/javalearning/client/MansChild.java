package org.javalearning.client;

import org.javalearning.abstraction.Man;

public class MansChild {

	
}
