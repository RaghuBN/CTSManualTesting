package OOP.Lessons.PS.RandomGenerator;

public class OccasionalDouble{
    public static void main(String[] args) {
        System.out.println("Cлучайное число: " + Math.random());
        System.out.println("Cлучайное число в диапазоне 0 - 100: " + (int) (Math.random() * 100));

    }
}
