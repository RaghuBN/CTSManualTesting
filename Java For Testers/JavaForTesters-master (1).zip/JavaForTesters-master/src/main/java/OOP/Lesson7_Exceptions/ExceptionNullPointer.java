package OOP.Lesson7_Exceptions;

public class ExceptionNullPointer {
    // Java program to demonstrate how exception is thrown.

        public static void main(String args[]){

            String str = null;
            System.out.println(str.length());

        }

}
