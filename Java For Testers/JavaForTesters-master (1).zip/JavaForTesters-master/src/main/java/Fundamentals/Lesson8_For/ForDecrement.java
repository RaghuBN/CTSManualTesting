package Fundamentals.Lesson8_For;

public class ForDecrement {
    public static void main(String[] args) {

        for (int life = 9; life >= 0; life--) {
            System.out.println("У кошки осталось жизней: " + life); // декремент
        }
    }
}
