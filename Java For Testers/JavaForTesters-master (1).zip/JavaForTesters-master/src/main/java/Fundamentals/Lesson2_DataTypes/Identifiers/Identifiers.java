package Fundamentals.Lesson2_DataTypes.Identifiers;

public class Identifiers {
    int MyVariable;
    String MYVARIABLE;
    String myvariable;
    short x;
    byte i;
    int x1;
    long i1;
    boolean _myvariable;
    double $myvariable;
    float sum_of_array;
    char char123;
    int прпржж;
}
