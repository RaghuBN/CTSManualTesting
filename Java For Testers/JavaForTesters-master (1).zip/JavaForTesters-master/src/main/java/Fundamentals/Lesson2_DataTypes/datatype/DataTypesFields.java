package Fundamentals.Lesson2_DataTypes.datatype;

public class DataTypesFields {
    boolean result = false;
    char capitalC = 'c';
    char ge = '\u0003';
    byte b = 100;
    short s = 10000;
    int i = 100000;
    long creditCardNumber = 1234_5678_9012_3456L;
    float pi = 3.14_15F;
    double d1 = 123.4;

}
