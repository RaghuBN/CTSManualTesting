package Fundamentals.Lesson1_Class.hello.world;

public class FirstTry {
    public static void main(String[] args) {
        System.out.print("Hello World!");
        System.out.println("Next Line");
    }
}
