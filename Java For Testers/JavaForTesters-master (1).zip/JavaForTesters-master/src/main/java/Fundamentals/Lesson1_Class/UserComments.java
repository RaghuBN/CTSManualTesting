package Fundamentals.Lesson1_Class;

public class UserComments {
    public static void main(String[] args) {
        //        Line comment  CTRL /
        System.out.println("Hello line");

        /*
                Few lines comment CTRL+SHIFT+/
         */
        /*System.out.println("Hello line");
         */

        /**
         * Documentation comment
         */

        /**
         * Assert.assertEquals сравнивает фактический и ожидаемый параметры.
         * Обратите внимание, что в методах Assert у testng первым параметром идет фактический результат,
         * а вторым ожидаемый.
         * В Assert у Junit наоборот!!! (expected, actual)
         */


        System.out.println("Hello world");
    }
}
