package Fundamentals.Lesson6_IfElse;

public class IfCleanSimple {
    public static void main(String[] args) {
        //if
        boolean bool = true;
        if (bool) System.out.println("bool - истина");

    }

}
