package Fundamentals.Lesson12_Arrays;

public class ArrayInit {
    {
        int[] integers = new int[10];
        int []moreInts = new int[10];
        int evenMore[] = new int[10];

        String strings[] = new String[10];
        strings = new String[] {"mr", "mrs", "sir", "lord", "madam"};

        int[] zeroLength = {};
        int[] moreZeroLength = new int[0];

        int[] ints1to10 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int[] uninitializedArray;
        uninitializedArray = new int[10];
        uninitializedArray = new int[] {100, 200, 300};

    }


}
