package OOP.Lesson6_Static;


public class ImportTest {

    @org.testng.annotations.Test
    public void nonImportTest(){

        org.testng.Assert.assertEquals(0b10 + 0b1, 0b11);
    }
}