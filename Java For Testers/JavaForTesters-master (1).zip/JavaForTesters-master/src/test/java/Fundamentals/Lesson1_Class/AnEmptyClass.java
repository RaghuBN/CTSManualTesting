package Fundamentals.Lesson1_Class;

public class AnEmptyClass {
}
