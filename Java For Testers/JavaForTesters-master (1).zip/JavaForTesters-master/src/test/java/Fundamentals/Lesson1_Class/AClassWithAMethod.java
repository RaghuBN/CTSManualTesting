package Fundamentals.Lesson1_Class;

public class AClassWithAMethod {

    //No main() inside, can't be run directly
    public void aMethodOnAClass(){

        System.out.println("Hello World");
    }
}
