var data = [
		{
			"_count" : "1",
			"_class" : "TestReport.Test1",
			"_mothod" : "testCase1",
			"_time" : "2000",
			"_status" : "SUCCESS",
			"_exception" : "--"
		},
		{
			"_count" : "2",
			"_class" : "TestReport.Test2",
			"_mothod" : "testCase2",
			"_time" : "3000",
			"_status" : "FAILED",
			"_exception" : "Error Explanation : / by zero\u003cbr\u003e Class Name :  TestReport.TestngAnnotation\u003cbr\u003e File Name :  TestngAnnotation.java\u003cbr\u003e Error Line Number :  31"
		}, {
			"_count" : "3",
			"_class" : "TestReport.Test3",
			"_mothod" : "testCase3",
			"_time" : "2500",
			"_status" : "SKIPED",
			"_exception" : "Skipping this exception"
		},
		{
			"_count" : "4",
			"_class" : "TestReport.Test4",
			"_mothod" : "testCase4",
			"_time" : "3500",
			"_status" : "SUCCESS",
			"_exception" : "--"
		}
		];
